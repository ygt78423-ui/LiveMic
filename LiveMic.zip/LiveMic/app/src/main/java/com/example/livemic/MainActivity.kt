package com.example.livemic

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var am: AudioManager
    private lateinit var inSpinner: Spinner
    private lateinit var outSpinner: Spinner
    private lateinit var toggle: Button
    private lateinit var statusView: TextView

    private var inputs: List<AudioDeviceInfo> = emptyList()
    private var outputs: List<AudioDeviceInfo> = emptyList()
    private var selIn = -1   // -1 = אוטומטי
    private var selOut = -1

    private val deviceCallback = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>?) = refreshDevices()
        override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>?) = refreshDevices()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        buildUi()
        refreshDevices()
        am.registerAudioDeviceCallback(deviceCallback, null)
    }

    override fun onResume() {
        super.onResume()
        MicService.listener = { running, msg -> runOnUiThread { render(running, msg) } }
        render(MicService.running, MicService.status)
    }

    override fun onPause() {
        MicService.listener = null
        super.onPause()
    }

    override fun onDestroy() {
        am.unregisterAudioDeviceCallback(deviceCallback)
        super.onDestroy()
    }

    // ---------- ממשק ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 16f
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(20), 0, dp(4))
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(32), dp(24), dp(24))
        }

        root.addView(TextView(this).apply {
            text = "מיקרופון חי"
            textSize = 28f
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "מה שנכנס למיקרופון יוצא מיד בפלט שנבחר"
            textSize = 14f
            setPadding(0, dp(4), 0, 0)
        })

        root.addView(label("מיקרופון (קלט)"))
        inSpinner = Spinner(this)
        root.addView(inSpinner)

        root.addView(label("רמקול (פלט)"))
        outSpinner = Spinner(this)
        root.addView(outSpinner)

        val refresh = Button(this).apply {
            text = "רענן רשימת התקנים"
            setOnClickListener { refreshDevices() }
        }
        root.addView(refresh)

        toggle = Button(this).apply {
            textSize = 22f
            setOnClickListener { onToggle() }
        }
        root.addView(toggle, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(88)
        ).apply { topMargin = dp(28) })

        statusView = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, 0)
        }
        root.addView(statusView)

        root.addView(TextView(this).apply {
            text = "טיפים: השתמש באוזניות או הרחק את הרמקול מהמיקרופון כדי למנוע צפצוף. " +
                "לשליטה בהשהיה בבלוטוס בחר התקן שמופיע כ'בלוטוס (שיחה)'."
            textSize = 13f
            setPadding(0, dp(24), 0, 0)
        })

        setContentView(root)

        inSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                selIn = if (pos == 0) -1 else inputs[pos - 1].id
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        outSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                selOut = if (pos == 0) -1 else outputs[pos - 1].id
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun render(running: Boolean, msg: String) {
        toggle.text = if (running) "עצור" else "התחל"
        statusView.text = msg
    }

    private fun typeName(d: AudioDeviceInfo): String = when (d.type) {
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> "מיקרופון הטלפון"
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "רמקול הטלפון"
        AudioDeviceInfo.TYPE_BUILTIN_EARPIECE -> "רמקול שיחה (אוזן)"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "בלוטוס (שיחה)"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "בלוטוס (מוזיקה, איכות גבוהה, השהיה גדולה)"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "אוזניות חוטיות עם מיקרופון"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "אוזניות חוטיות"
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
        else -> if (Build.VERSION.SDK_INT >= 31 &&
            (d.type == AudioDeviceInfo.TYPE_BLE_HEADSET || d.type == AudioDeviceInfo.TYPE_BLE_SPEAKER)
        ) "בלוטוס LE" else "התקן (${d.type})"
    }

    private fun name(d: AudioDeviceInfo): String {
        val product = d.productName?.toString().orEmpty()
        val t = typeName(d)
        return if (product.isNotBlank() && !t.startsWith("מיקרופון הטלפון") && !t.startsWith("רמקול הטלפון"))
            "$t – $product" else t
    }

    private fun refreshDevices() {
        inputs = am.getDevices(AudioManager.GET_DEVICES_INPUTS).toList()
        outputs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).toList()
        fill(inSpinner, inputs, selIn)
        fill(outSpinner, outputs, selOut)
    }

    private fun fill(sp: Spinner, devs: List<AudioDeviceInfo>, selectedId: Int) {
        val labels = listOf("אוטומטי") + devs.map { name(it) }
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        val idx = devs.indexOfFirst { it.id == selectedId }
        sp.setSelection(if (idx >= 0) idx + 1 else 0)
    }

    // ---------- הרשאות והפעלה ----------

    private fun onToggle() {
        if (MicService.running) {
            startService(Intent(this, MicService::class.java).setAction(MicService.ACTION_STOP))
            return
        }
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) needed += Manifest.permission.BLUETOOTH_CONNECT
        if (Build.VERSION.SDK_INT >= 33) needed += Manifest.permission.POST_NOTIFICATIONS
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startMic() else requestPermissions(missing.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startMic()
        } else {
            statusView.text = "בלי הרשאת מיקרופון האפליקציה לא יכולה לעבוד"
        }
    }

    private fun startMic() {
        val i = Intent(this, MicService::class.java)
            .setAction(MicService.ACTION_START)
            .putExtra(MicService.EXTRA_IN, selIn)
            .putExtra(MicService.EXTRA_OUT, selOut)
        startForegroundService(i)
    }
}
