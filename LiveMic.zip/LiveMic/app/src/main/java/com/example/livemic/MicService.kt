package com.example.livemic

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** שירות חזית, כדי שהמיקרופון ימשיך לעבוד גם כשהמסך כבוי או האפליקציה ברקע. */
class MicService : Service() {

    companion object {
        const val ACTION_START = "livemic.START"
        const val ACTION_STOP = "livemic.STOP"
        const val EXTRA_IN = "in"
        const val EXTRA_OUT = "out"
        private const val CHANNEL = "live_mic"

        @Volatile var running = false
        @Volatile var status = "מופסק"
        @Volatile var listener: ((Boolean, String) -> Unit)? = null
    }

    private var engine: AudioEngine? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START) {
            goForeground()
            engine?.stop()
            running = true
            status = "מתחבר..."
            listener?.invoke(true, status)
            engine = AudioEngine(this) { isRunning, msg ->
                running = isRunning
                status = msg
                listener?.invoke(isRunning, msg)
                if (!isRunning) stopSelf()
            }.also {
                it.start(intent.getIntExtra(EXTRA_IN, -1), intent.getIntExtra(EXTRA_OUT, -1))
            }
        } else {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        engine?.stop()
        engine = null
        running = false
        super.onDestroy()
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "מיקרופון חי", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, MicService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("מיקרופון חי פעיל")
            .setContentText("לחץ לפתיחה")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(null, "עצור", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, n)
        }
    }
}
