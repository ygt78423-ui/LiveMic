package com.example.livemic

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.Process
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * מעביר אודיו מהמיקרופון ישר לפלט בלולאה אחת, עם הכי מעט חיץ (buffer) שאפשר.
 * מצב "שיחה": כשאחד ההתקנים הוא בלוטוס SCO/HFP, עוברים ל-MODE_IN_COMMUNICATION
 * ומנתבים לערוץ השיחה של הבלוטוס (השהיה נמוכה), בדיוק כמו שיחת טלפון.
 */
class AudioEngine(
    private val ctx: Context,
    private val onState: (running: Boolean, message: String) -> Unit
) {
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    @Volatile private var running = false
    private var thread: Thread? = null
    private var scoReceiver: BroadcastReceiver? = null
    private var callMode = false

    companion object {
        fun isBluetoothCall(d: AudioDeviceInfo?): Boolean {
            if (d == null) return false
            if (d.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO) return true
            return Build.VERSION.SDK_INT >= 31 && d.type == AudioDeviceInfo.TYPE_BLE_HEADSET
        }
    }

    fun start(inId: Int, outId: Int) {
        val inDev = am.getDevices(AudioManager.GET_DEVICES_INPUTS).firstOrNull { it.id == inId }
        val outDev = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull { it.id == outId }
        callMode = isBluetoothCall(inDev) || isBluetoothCall(outDev)
        running = true
        thread = Thread({ loop(inDev, outDev) }, "live-mic").also { it.start() }
    }

    fun stop() {
        running = false
        thread?.join(800)
        thread = null
    }

    private fun loop(inDev: AudioDeviceInfo?, outDev: AudioDeviceInfo?) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        var rec: AudioRecord? = null
        var trk: AudioTrack? = null
        var message = "הופסק"
        try {
            if (callMode && !enterCallMode(inDev, outDev)) {
                message = "לא הצלחתי להפעיל את ערוץ השיחה של הבלוטוס. ודא שההתקן מחובר ותומך בשיחות (HFP)."
                return
            }

            val nativeRate = am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull() ?: 48000
            val burst = am.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)?.toIntOrNull() ?: 192
            val rate = if (callMode) 16000 else nativeRate
            val chunk = if (callMode) 160 else burst // ~10ms בשיחה, מקטע חומרה אחד אחרת

            val inMask = AudioFormat.CHANNEL_IN_MONO
            val outMask = AudioFormat.CHANNEL_OUT_MONO
            val enc = AudioFormat.ENCODING_PCM_16BIT

            val recBytes = maxOf(AudioRecord.getMinBufferSize(rate, inMask, enc), chunk * 2 * 2)
            rec = AudioRecord.Builder()
                .setAudioSource(
                    if (callMode) MediaRecorder.AudioSource.VOICE_COMMUNICATION
                    else MediaRecorder.AudioSource.MIC
                )
                .setAudioFormat(
                    AudioFormat.Builder().setEncoding(enc).setSampleRate(rate).setChannelMask(inMask).build()
                )
                .setBufferSizeInBytes(recBytes)
                .build()
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                message = "המיקרופון לא נפתח (אולי אפליקציה אחרת משתמשת בו)"
                return
            }
            if (inDev != null) rec.setPreferredDevice(inDev)

            val trkBytes = maxOf(AudioTrack.getMinBufferSize(rate, outMask, enc), chunk * 2 * 2)
            trk = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(
                            if (callMode) AudioAttributes.USAGE_VOICE_COMMUNICATION
                            else AudioAttributes.USAGE_MEDIA
                        )
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder().setEncoding(enc).setSampleRate(rate).setChannelMask(outMask).build()
                )
                .setBufferSizeInBytes(trkBytes)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()
            if (outDev != null) trk.setPreferredDevice(outDev)
            trk.setBufferSizeInFrames(chunk * 2) // חיץ קטן ככל שהמערכת מרשה

            val buf = ShortArray(chunk)
            // מקטע שקט אחד כדי למנוע קטיעות בהתחלה
            trk.write(buf, 0, chunk, AudioTrack.WRITE_BLOCKING)
            rec.startRecording()
            trk.play()

            val mode = if (callMode) "מצב שיחה (בלוטוס)" else "מצב רגיל"
            onState(true, "פעיל • $mode • ${rate}Hz • מקטע ${chunk * 1000 / rate}ms")

            while (running) {
                val n = rec.read(buf, 0, chunk, AudioRecord.READ_BLOCKING)
                if (n > 0) {
                    trk.write(buf, 0, n, AudioTrack.WRITE_BLOCKING)
                } else if (n < 0) {
                    message = "שגיאת הקלטה ($n)"
                    break
                }
            }
        } catch (e: Exception) {
            message = "שגיאה: ${e.message}"
        } finally {
            try { rec?.stop() } catch (_: Exception) {}
            rec?.release()
            try { trk?.stop() } catch (_: Exception) {}
            trk?.release()
            exitCallMode()
            running = false
            onState(false, message)
        }
    }

    // ---------- מצב שיחה / בלוטוס ----------

    @Suppress("DEPRECATION")
    private fun enterCallMode(inDev: AudioDeviceInfo?, outDev: AudioDeviceInfo?): Boolean {
        am.mode = AudioManager.MODE_IN_COMMUNICATION
        val chosen = listOf(outDev, inDev).firstOrNull { isBluetoothCall(it) }
        if (Build.VERSION.SDK_INT >= 31) {
            val candidates = am.availableCommunicationDevices
            val target = candidates.firstOrNull { it.id == chosen?.id }
                ?: candidates.firstOrNull { isBluetoothCall(it) }
                ?: return false
            return am.setCommunicationDevice(target)
        }
        // אנדרואיד 8-11: פותחים ערוץ SCO ומחכים לחיבור
        val latch = CountDownLatch(1)
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                val s = i?.getIntExtra(AudioManager.EXTRA_SCO_AUDIO_STATE, -1)
                if (s == AudioManager.SCO_AUDIO_STATE_CONNECTED) latch.countDown()
            }
        }
        scoReceiver = receiver
        ctx.registerReceiver(receiver, IntentFilter(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED))
        am.startBluetoothSco()
        am.isBluetoothScoOn = true
        return latch.await(4, TimeUnit.SECONDS)
    }

    @Suppress("DEPRECATION")
    private fun exitCallMode() {
        if (!callMode) return
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                am.clearCommunicationDevice()
            } else {
                am.stopBluetoothSco()
                am.isBluetoothScoOn = false
            }
            scoReceiver?.let { ctx.unregisterReceiver(it) }
        } catch (_: Exception) {}
        scoReceiver = null
        am.mode = AudioManager.MODE_NORMAL
    }
}
